drop database if exists warehouse;

create database warehouse;

use warehouse;

create table users(
	 username varchar(32) not null primary key,
     passwd varchar(30) not null,
     company varchar(50),
     user_type varchar(32) default '0'
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

insert into users values('123', '123',null, '0');

create table product(
	pro_id varchar(32) not null primary key,
    pro_name varchar(30),
    pro_spe varchar(30),
    pro_uppler int,
    pro_lower int,
    pro_sale float,
    pro_purchase float,
    pro_code varchar(40),
    pro_brand varchar(40),
    pro_model varchar(40),
	pro_describe varchar(2000),
    pro_maks varchar(200),
    pro_unit varchar(30),
    pro_issue int,
    pro_state int ,
    pro_number int,
     ware_id varchar(31) references warehouse(ware_id) ,
    pro_category varchar(30) references category(ca_id) ,
    l_id  varchar(32) references customerLevel(l_id),
    username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

insert into product(pro_id, pro_name,pro_spe, pro_uppler,pro_lower, pro_sale,pro_purchase, pro_code, pro_brand, pro_model,
 pro_describe,pro_maks,pro_unit,pro_category, pro_issue, pro_state, pro_number, l_id, username) values('1', '笔记本',null, 20, 0,3, 2,null,null,null,
 null,null, '本','1',0,0,100,null, '123'),('2', '圆珠笔',null, 200, 0,3, 2,null,null,null,
 null,null, '支','1',0,0,100,null, '123'),('3', '电脑',null, 200, 0,5000, 4500,null,null,null,
 null,null, '台','1',0,0,30,null, '123'),('4', '电脑',null, 50, 10,5100, 4500,null,null,null,null,null, '台','1',0,20,0,null, '123'),('5', '椅子',null, 50, 100,200, 300,null,null,null,null,null, '台','1',0,1,40,null, '123');

create table picture(
	pic_id varchar(32) not null primary key,
    pic_name varchar(150),
    pro_id varchar(32) references product(pro_id)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table enclosure(
	en_id varchar(32) not null primary key,
    en_name varchar(100),
    pro_id varchar(32) references product(pro_id),
    sp_id varchar(50) references supplier(sp_id),
    pur_id varchar(32) references purchase(pur_id),
    so_id varchar(32) references saleOrder(so_id),
    c_id varchar(32) references customer(c_id),
    inb_id varchar(32) references inbound(inb_id),
    out_id varchar(32) references outbound(out_id),
    sto_id varchar(32) references stocktaking(sto_id),
    sch_id varchar(32) references scheduling(sch_id),
    in_id varchar(32) references income(in_id),
    exp_id varchar(32) references expend(exp_id),
    sai_id varchar(32) references saleInvoice(sai_id),
    invo_id varchar(32) references invoice(invo_id)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table  customerLevel(
	l_id varchar(32) not null primary key,
    l_name varchar(30),
    l_discount int,
     username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table  category(
	ca_id varchar(32) not null primary key,
    ca_name varchar(30),
    ca_parent varchar(32) default '0',
    username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

insert into category(ca_id,ca_name,ca_parent) values('1','其他',0);

create table unit(
		u_id varchar(32) not null primary key,
        u_name varchar(20),
        username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

insert into unit(u_id,u_name) values('1','件'),('2','卷'),('3','条'),('4','公斤'),('5','台'),('6','支');

create table custom(
	cus_id varchar(32) not null primary key,
    cus_name varchar(30) ,
    cus_content varchar(50),
    pro_id varchar(32) references product(pro_id),
    sp_id varchar(32) references supplier(sp_id),
    pur_id varchar(32) references purchase(pur_id),
    so_id varchar(32) references saleOrder(so_id),
    c_id varchar(32) references customer(c_id),
    inb_id varchar(32) references inbound(inb_id),
    out_id varchar(32) references outbound(out_id),
    cus_type int,
    username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table  purchase(
	pur_id varchar(32) not null primary key,
    pur_time date,
    pur_code varchar(40),
    pur_purchase varchar(30),
    pur_phone varchar(30),
    pur_contacts varchar(30),
    pur_maks varchar(200),
    pur_address varchar(50),
    pur_method varchar(30),
    pur_mode varchar(30),
    pur_state int default 0,
    pur_makeDate date,
    pur_modifier varchar(30),
    pur_modifierDate date,
    pur_paidPrice Float,
    pur_unPaidPrice Float,
    pur_arrivalAccount Float,
    pur_unArrivalAccount Float,
    put_num int,
    pur_sum Float,
    state int default 0,
    pur_spName varchar(20),
    pur_sPhone varchar(20),
	sp_id varchar(32) references supplier(sp_id),
     username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table  supplier(
	sp_id varchar(50) not null primary key,
    s_contacts varchar(32),
    s_phone varchar(20),
    s_mail varchar(30),
    s_username varchar(30),
    s_legalperson varchar(10),
    s_address varchar(50),
    s_code varchar(40),
    s_maks varchar(200),
    s_state int default 0
)ENGINE=INNODB DEFAULT CHARSET=UTF8;
insert into supplier(sp_id,s_username) values('123','123');

create table  purdetails(
	pud_id varchar(32) not null primary key,
    pud_num int,
    pud_unPrice Float,
    pud_price Float,
    pud_sumPrice Float,
    pud_taxRate int,
    pud_taxPrice Float,
    pud_sumMoney Float,
    pud_time date,
    pud_maks varchar(200),
    pud_proName varchar(30),
    pud_spe varchar(30),
    pud_unit varchar(30),
    pud_brand varchar(40),
    pud_mode varchar(40),
    pud_category varchar(40),
    pud_code varchar(40),
    pud_quantity int,
    pud_unQuantity int,
    pud_order varchar(50),
    pud_goodsId varchar(32),
	pur_id varchar(32) references purchase(pur_id),
    so_id varchar(32) references saleOrder(so_id),
    inb_id varchar(32) references inbound(inb_id),
    out_id varchar(32) references outbound(out_id)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table address(
	ad_id varchar(32) not null primary key,
    ad_location varchar(50),
    ad_detailed varchar(50),
    ad_state int ,
    c_id varchar(32) references customer(c_id),
    username varchar(32) references users(username)
    )ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table project(
	pr_id varchar(32) not null primary key,
    pr_name varchar(30),
    username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

insert into project values('1', '采购', '123');
insert into project values('2', '销售', '123');

create table method(
	met_id varchar(32) not null primary key,
    met_mode varchar(30),
    username varchar(32) null references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

insert into method(met_id, met_mode) values('1','现金'),('2','银行转账'),('3','支付宝'),('4','微信'),('5','银行承兑汇票');

create table taxRate(
	tr_id varchar(32) not null primary key,
    tr_discount int,
    tr_type int,
    username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

insert into taxRate(tr_id, tr_discount, tr_type) values('1',0,0);

create table saleOrder(
	so_id varchar(32) not null primary key,
    so_time date,
    so_code varchar(40),
    so_address varchar(50),
    so_project varchar(30),
    so_method varchar(30),
    so_order varchar(30),
    so_name varchar(30),
    so_contacts varchar(30),
    so_phone varchar(30),
    so_maks varchar(200),
    so_state int,
    so_makeDate date,
    so_modifier varchar(30),
    so_modifierDate date,
    so_num int,
    so_sum Float,
    so_customerName varchar(20),
    so_customerPhone varchar(20),
    so_receivables Float,
    so_unReceivables Float,
    so_invoice Float,
    so_unInvoice Float,
    state int,
    username varchar(32) references users(username),
    c_id varchar(32) references customer(c_id)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table  customer(
	c_id varchar(50) not null primary key,
    c_name varchar(20),
    c_phone varchar(20),
    c_mail varchar(30),
    c_username varchar(30),
    c_lefalperson varchar(20),
    c_address varchar(50),
    c_code varchar(50),
    c_remaks varchar(200),
    c_state int,
    c_cstate varchar(30)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table  customerState(
	cs_id varchar(32) not null primary key,
    cs_name varchar(30)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table inbound(
	inb_id varchar(32) not null primary key,
    inb_type int,
    inb_date date,
    inb_ware varchar(30),
    inb_code varchar(40),
    inb_project varchar(30),
    inb_handle varchar(30),
    inb_maks varchar(200),
    inb_modifier varchar(30) ,
    inb_modifierDate date,
    inb_makeDate date,
    inb_num int,
    inb_sum Float,
    username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table  produce(
	pr_id varchar(32) not null primary key,
    pr_depart varchar(30),
    pr_employee varchar(30),
    inb_id varchar(32) references inbound(inb_id)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table  purInbound(
	pui_id varchar(32) not null primary key,
    pui_supId varchar(50),
    pui_contacts varchar(30),
    pui_phone varchar(30),
    inb_id varchar(32) references inbound(inb_id),
    pur_id varchar(32) references purchase(pur_id)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table  saleInbound(
	sai_id varchar(32) not null primary key,
    sai_csuId varchar(50),
    sai_contacts varchar(30),
    sai_phone varchar(30),
    inb_id varchar(32) references inbound(inb_id)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table  otherInbound(
	oi_id varchar(32) not null primary key,
    oi_name varchar(30),
    oi_contacts varchar(30),
    inb_id varchar(32) references inbound(inb_id)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table  warehouse(
	ware_id varchar(32) not null primary key,
    ware_name varchar(30),
    ware_address varchar(50),
     username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

insert into warehouse values('1', '本地','本地',null);

create table department(
	de_id varchar(32) not null primary key,
    de_name varchar(30),
    username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table  employee(
	em_id varchar(32) not null primary key,
    em_name varchar(30),
    em_phone varchar(30),
    de_id varchar(32) references department(de_id)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;


create table outbound(
	out_id varchar(32) not null primary key,
    out_type int,
    out_date date,
    out_ware varchar(30),
    out_code varchar(40),
    out_express varchar(30),
    out_identifer varchar(40),
    out_project varchar(30),
    out_handle varchar(30),
    out_maks varchar(200),
    out_makeDate date,
    out_modifier varchar(30),
    out_modiferDate date,
    username varchar(32) references users(username),
    sout_id varchar(32) references saleOutbound(sout_id),
    oi_id varchar(32) references otherInbound(oi_id),
    pui_id varchar(32) references purInbound(pui_id),
    pr_id varchar(32) references produce(pr_id)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table express(
	exp_id varchar(32) not null primary key,
    exp_name varchar(30),
     username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

insert into express(exp_id, exp_name, username) values('1', '中通快递', null),('2', '韵达快递', null),('3', '顺丰快递', null),('4', '圆通快递', null);

create table saleOutbound(
	sout_id varchar(32) not null primary key,
    sout_customerId varchar(32),
    sout_contacts varchar(30),
    sout_phone varchar(30),
    sout_adress varchar(50)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table stocktaking(
	sto_id varchar(32) not null primary key,
    sto_date date,
    sto_ware varchar(30),
    sto_code varchar(40),
    sto_contacts varchar(30),
    sto_maks varchar(200),
    sto_makeDate date,
    username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table stocktakingInfo(
	sti_id varchar(32) not null primary key,
    sti_proId varchar(32),
    sti_name varchar(30),
    sti_unit varchar(30),
    sti_category varchar(40),
    sti_code varchar(40),
    sti_num int,
    sti_stockNum int,
    sti_result varchar(30),
    sto_resultNum int,
    sti_remaks varchar(200),
    sto_id varchar(32) references stocktaking(sto_id)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table scheduling(
	sch_id varchar(32) not null primary key,
    sch_date date,
    sch_enter varchar(30),
    sch_out varchar(30),
    sch_code varchar(40),
    sch_contacts varchar(30),
    sch_maks varchar(200)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table schedulInfo(
	sci_id varchar(32) not null primary key,
    sci_proId varchar(32),
    sci_name varchar(30),
    sci_spe varchar(30),
    sci_unit varchar(30),
    sci_category varchar(40),
    sci_code varchar(40),
    sci_num int,
    sci_maks varchar(200),
    sch_makeDate date,
    username varchar(32) references users(username),
    sch_id varchar(32) references scheduling(sch_id)    
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table income(
	in_id varchar(32) not null primary key,
    in_date date ,
    in_inType varchar(32),
    in_accName varchar(30),
    in_name varchar(30),
    in_maks varchar(200),
    in_money Float,
    in_makeDate date,
    in_modifierDate date,
    in_modifierName varchar(30),
    in_type int,
    username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table incomeType(
	int_id varchar(32) not null primary key,
    int_type varchar(30),
    username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table account(
	acc_id varchar(32) not null primary key,
    acc_name varchar(30),
     username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table incomeInfo(
	ini_id varchar(32) not null primary key,
    ini_saleId varchar(32),
    ini_sumoney Float,
    ini_money Float,
    ini_maks varchar(200),
    in_id varchar(32) references income(in_id),
    exp_id varchar(32) references expend(exp_id),
    sai_id varchar(32) references saleInvoice(sai_id)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table expend(
	exp_id varchar(32) not null primary key,
    exp_date date,
    exp_typeName varchar(30),
    exp_account varchar(30),
    exp_receivingParty varchar(30),
    exp_type int,
    exp_money Float,
    exp_maks varchar(200),
    exp_makeDate date,
    exp_modifier varchar(30),
    exp_modidierDate date,
    username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table expendType(
	expt_id varchar(32) not null primary key,
    expt_name varchar(30),
     username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table saleInvoice(
	sai_id varchar(32) not null primary key,
    sai_time date,
    sai_receivingParty varchar(30),
    sai_invoiceCode varchar(40),
    sai_invoiceName varchar(30),
    sai_type int,
    sai_sumoney Float,
    sai_maks varchar(200)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table invoiceType(
	invt_id varchar(32) not null primary key,
    invt_name varchar(30),
     username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

insert into invoiceType(invt_id, invt_name, username)values('1', '增值税专用发票', null), ('2','增值税普通发票', null);

create table invoice(
	invo_id varchar(32) not null primary key,
    invo_time date,
    invo_drawerParty varchar(30),
    invo_invoiceName varchar(30),
    invo_type int,
    invo_sumoney Float,
    invo_maks varchar(200),
     username varchar(32) references users(username)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

create table documentNumber(
	docn_id varchar(32) not null primary key,
    docn_dateType int,
    docn_type varchar(20)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;
create table documentPrefix(
	dp_id varchar(32) not null primary key,
    dp_name varchar(30),
    dp_type int,
    username varchar(32) references users(username),
    docn_id varchar(32) references documentNumber(docn_id)
)ENGINE=INNODB DEFAULT CHARSET=UTF8;

insert into documentNumber values('1', 0, 'CK');
insert into documentNumber values('2', 0, 'RK');
insert into documentNumber values('3', 0, 'CG');
insert into documentNumber values('4', 0, 'XS');

insert into documentPrefix values('1', 'CK', 0, null, 1 ),('2', 'RK', 0, null, 2),('3', 'DD', 0,null, 3),('4', 'XS', 0, null, 4), ('5', 'RD', 1, '123', 1);







